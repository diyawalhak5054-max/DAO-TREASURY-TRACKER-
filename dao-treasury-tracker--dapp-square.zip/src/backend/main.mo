import Principal "mo:base/Principal";
import Time "mo:base/Time";
import Array "mo:base/Array";
import Option "mo:base/Option";
import Result "mo:base/Result";
import Nat "mo:base/Nat";
import Nat64 "mo:base/Nat64";
import Int "mo:base/Int";
import Text "mo:base/Text";
import Error "mo:base/Error";
import Debug "mo:base/Debug";
import Blob "mo:base/Blob";

shared actor class DAOTreasury() = Self {

  // ============================================================
  // ICRC-1 LEDGER INTERFACE (for native DAO token)
  // ============================================================

  type Account = { owner : Principal; subaccount : ?Blob };

  type Icrc1TransferArgs = {
    from_subaccount : ?Blob;
    to : Account;
    amount : Nat;
    fee : ?Nat;
    memo : ?Blob;
    created_at_time : ?Nat64;
  };

  type Icrc1TransferError = {
    #InsufficientFunds : { balance : Nat };
    #BadFee : { expected_fee : Nat };
    #BadBurn : { min_burn_amount : Nat };
    #GenericError : { error_code : Nat; message : Text };
    #TemporarilyUnavailable;
    #Duplicate : { duplicate_of : Nat };
    #TooOld;
    #CreatedInFuture : { ledger_time : Nat64 };
  };

  type Icrc1TransferResult = { #Ok : Nat; #Err : Icrc1TransferError };

  type Icrc1TokenMetadata = [(Text, { #Text : Text; #Nat : Nat; #Int : Int; #Blob : Blob })];

  /// Minimal ICRC-1 ledger actor interface used for cross-canister calls.
  type Icrc1LedgerActor = actor {
    icrc1_transfer : (Icrc1TransferArgs) -> async Icrc1TransferResult;
    icrc1_balance_of : (Account) -> async Nat;
    icrc1_total_supply : () -> async Nat;
    icrc1_metadata : () -> async Icrc1TokenMetadata;
    icrc1_minting_account : () -> async ?Account;
  };

  // ============================================================
  // DAO TOKEN (ICRC-1) CONFIGURATION
  // ============================================================

  /// Token symbol (e.g. "DAO").
  let TOKEN_SYMBOL : Text = "DAO";

  /// Token decimals (8 for DAO token).
  let TOKEN_DECIMALS : Nat = 8;

  /// Default airdrop amount (in base units — 1000 tokens × 10^8 = 100_000_000_000).
  let AIRDROP_AMOUNT : Nat = 100_000_000_000;

  /// Minimum token balance required to vote (1 token in base units — 10^8).
  let MIN_VOTING_TOKENS : Nat = 100_000_000;

  /// Minimum lock period for staking (30 days in nanoseconds).
  let STAKING_MIN_LOCK_NS : Int = 30 * 24 * 60 * 60 * 1_000_000_000;

  /// Annual percentage yield for staking (5 % expressed as basis points: 500 = 5.00 %).
  let STAKING_APY_BPS : Nat = 500;

  /// Fee discount threshold — holding at least this many tokens gives a discount (1000 tokens).
  let FEE_DISCOUNT_THRESHOLD : Nat = 100_000_000_000;

  /// Fee discount percentage when holding >= FEE_DISCOUNT_THRESHOLD (10 % expressed as basis points).
  let FEE_DISCOUNT_BPS : Nat = 1000;

  /// Default transaction fee in basis points (0.5 % = 50 bps) for payments.
  let DEFAULT_FEE_BPS : Nat = 50;

  // ============================================================
  // TYPES
  // ============================================================

  /// Role assigned to each DAO member.
  public type MemberRole = {
    #admin;
    #member;
  };

  /// A DAO member identified by their Internet Identity principal.
  public type Member = {
    principal : Principal;
    role : MemberRole;
    name : Text;
    joinedAt : Int;               // Time.now() nanosecond timestamp
  };

  /// Token / asset symbol (e.g. "ICP", "BTC", "ckUSDC", "DTC").
  public type TokenSymbol = Text;

  /// Kind of on-chain financial event.
  public type TransactionType = {
    #deposit;                     // external funds credited to DAO
    #withdrawal;                  // funds sent out of DAO treasury
    #payment;                     // payment to a recipient
  };

  /// Lifecycle of a transaction.
  public type TransactionStatus = {
    #pending;
    #completed;
    #failed;
  };

  /// Immutable ledger entry for every value movement.
  public type Transaction = {
    id : Nat;
    initiator : Principal;        // who triggered the tx
    fromPrincipal : Principal;    // treasury / member principal
    toPrincipal : ?Principal;     // recipient (if on-chain)
    toAddress : ?Text;            // external address (if off-chain)
    token : TokenSymbol;
    amount : Nat;
    txType : TransactionType;
    status : TransactionStatus;
    description : Text;
    timestamp : Int;              // Time.now()
  };

  /// Vote cast by a member.
  public type VoteChoice = {
    #for_;
    #against;
  };

  /// Governance proposal lifecycle.
  public type ProposalStatus = {
    #active;                      // open for voting
    #passed;                      // reached quorum + majority
    #rejected;                    // failed to pass
    #executed;                    // action has been performed
    #cancelled;                   // withdrawn by proposer or admin
  };

  /// A governance proposal — uses token-weighted voting.
  /// votesFor / votesAgainst now represent total token weight, not headcount.
  public type Proposal = {
    id : Nat;
    proposer : Principal;
    title : Text;
    description : Text;
    token : TokenSymbol;          // token for payment proposals (empty = no payment)
    amount : Nat;                 // 0 for non-payment proposals
    recipient : ?Principal;       // recipient for payment proposals
    status : ProposalStatus;
    votesFor : Nat;               // total token-weight votes FOR
    votesAgainst : Nat;           // total token-weight votes AGAINST
    voters : [Principal];         // members who already voted (prevents double-vote)
    createdAt : Int;
    votingDeadline : Int;         // Time.now() + voting period
    executedAt : ?Int;
  };

  /// Public-facing balance entry.
  public type BalanceEntry = {
    token : TokenSymbol;
    amount : Nat;
  };

  /// Member summary returned to frontend.
  public type MemberInfo = {
    principal : Principal;
    role : MemberRole;
    name : Text;
    joinedAt : Int;
  };

  /// Staking position for a member.
  public type StakePosition = {
    principal : Principal;
    amount : Nat;                 // staked token amount (base units)
    lockedUntil : Int;            // Time.now() when lock expires
    rewardedAt : Int;             // last reward timestamp
    accumulatedRewards : Nat;     // unclaimed rewards
  };

  /// Token metadata returned to frontend.
  public type TokenMetadata = {
    symbol : Text;
    name : Text;
    decimals : Nat;
    totalSupply : Nat;
  };

  /// Token info for a member (balance + voting power + staking).
  public type MemberTokenInfo = {
    principal : Principal;
    tokenBalance : Nat;
    stakedBalance : Nat;
    votingPower : Nat;
    pendingRewards : Nat;
    hasFeeDiscount : Bool;
  };

  // ============================================================
  // CONSTANTS
  // ============================================================

  /// Voting window: 7 days in nanoseconds.
  let VOTING_PERIOD_NS : Int = 7 * 24 * 60 * 60 * 1_000_000_000;

  /// Fraction of members who must vote for a proposal to be valid.
  /// Expressed as numerator / denominator (i.e. 1 / 2 = simple majority).
  let QUORUM_NUMERATOR : Nat = 1;
  let QUORUM_DENOMINATOR : Nat = 2;

  /// Fraction of votes that must be #for_ for a proposal to pass.
  let MAJORITY_NUMERATOR : Nat = 1;
  let MAJORITY_DENOMINATOR : Nat = 2;

  // ============================================================
  // STABLE STATE — survives canister upgrades
  // ============================================================

  stable var _members : [Member] = [];
  stable var _balances : [(Principal, [(TokenSymbol, Nat)])] = [];
  stable var _transactions : [Transaction] = [];
  stable var _proposals : [Proposal] = [];
  stable var _nextTxId : Nat = 0;
  stable var _nextProposalId : Nat = 0;

  // DAO token state
  stable var _stakes : [(Principal, StakePosition)] = [];
  stable var _tokenLedgerCanisterId : ?Text = null;
  stable var _airdropped : [Principal] = [];
  stable var _totalStaked : Nat = 0;
  stable var _totalRewardsDistributed : Nat = 0;

  // ============================================================
  // AUTHORIZATION HELPERS
  // ============================================================

  /// Find a member by principal. Returns null if not found.
  func findMember(p : Principal) : ?Member {
    Array.find<Member>(_members, func(m : Member) : Bool { m.principal == p });
  };

  /// True when the principal is a registered member.
  func isMember(p : Principal) : Bool {
    Option.isSome(findMember(p));
  };

  /// True when the principal has the #admin role.
  func isAdmin(p : Principal) : Bool {
    switch (findMember(p)) {
      case (?m) { m.role == #admin };
      case null { false };
    };
  };

  /// Assert that `caller` is a member; trap with 403 otherwise.
  func requireMember(caller : Principal) : () {
    if (not isMember(caller)) {
      throw Error.reject("403: caller is not a DAO member — principal " # Principal.toText(caller));
    };
  };

  /// Assert that `caller` is an admin; trap with 403 otherwise.
  func requireAdmin(caller : Principal) : () {
    if (not isAdmin(caller)) {
      throw Error.reject("403: caller is not a DAO admin — principal " # Principal.toText(caller));
    };
  };

  // ============================================================
  // BALANCE HELPERS
  // ============================================================

  /// Look up the balance for a single (principal, token) pair.
  func lookupBalance(p : Principal, token : TokenSymbol) : Nat {
    switch (Array.find<(Principal, [(TokenSymbol, Nat)])>(
      _balances,
      func(entry : (Principal, [(TokenSymbol, Nat)])) : Bool { entry.0 == p }
    )) {
      case (?(_, tokenEntries)) {
        switch (Array.find<(TokenSymbol, Nat)>(tokenEntries, func(t : (TokenSymbol, Nat)) : Bool { t.0 == token })) {
          case (?(_, amt)) { amt };
          case null { 0 };
        };
      };
      case null { 0 };
    };
  };

  /// Set the balance for a single (principal, token) pair, adding the
  /// principal-level entry when it does not exist yet.
  func setBalance(p : Principal, token : TokenSymbol, amount : Nat) : () {
    var found : Bool = false;
    _balances := Array.map<(Principal, [(TokenSymbol, Nat)]), (Principal, [(TokenSymbol, Nat)])>(
      _balances,
      func(entry : (Principal, [(TokenSymbol, Nat)])) : (Principal, [(TokenSymbol, Nat)]) {
        if (entry.0 == p) {
          found := true;
          var tokenFound : Bool = false;
          let updatedTokens = Array.map<(TokenSymbol, Nat), (TokenSymbol, Nat)>(
            entry.1,
            func(t : (TokenSymbol, Nat)) : (TokenSymbol, Nat) {
              if (t.0 == token) { tokenFound := true; (t.0, amount) } else { t }
            }
          );
          if (tokenFound) {
            (p, updatedTokens)
          } else {
            (p, Array.flatten<(TokenSymbol, Nat)>([updatedTokens, [(token, amount)]]))
          };
        } else {
          entry
        }
      }
    );
    if (not found) {
      _balances := Array.flatten<(Principal, [(TokenSymbol, Nat)])>([
        _balances,
        [(p, [(token, amount)])]
      ]);
    };
  };

  /// Add `amount` to the existing balance of (principal, token).
  func addBalance(p : Principal, token : TokenSymbol, amount : Nat) : () {
    let current = lookupBalance(p, token);
    setBalance(p, token, current + amount);
  };

  /// Subtract `amount` from the existing balance of (principal, token).
  /// Traps if the balance would go below zero.
  func subtractBalance(p : Principal, token : TokenSymbol, amount : Nat) : () {
    let current = lookupBalance(p, token);
    if (current < amount) {
      throw Error.reject("400: insufficient balance — have " # Nat.toText(current) # " " # token # ", need " # Nat.toText(amount));
    };
    setBalance(p, token, current - amount);
  };

  // ============================================================
  // TRANSACTION LOG HELPERS
  // ============================================================

  func logTransaction(
    initiator : Principal,
    fromPrincipal : Principal,
    toPrincipal : ?Principal,
    toAddress : ?Text,
    token : TokenSymbol,
    amount : Nat,
    txType : TransactionType,
    status : TransactionStatus,
    description : Text,
  ) : Nat {
    let id = _nextTxId;
    _nextTxId += 1;
    let tx : Transaction = {
      id;
      initiator;
      fromPrincipal;
      toPrincipal;
      toAddress;
      token;
      amount;
      txType;
      status;
      description;
      timestamp = Time.now();
    };
    _transactions := Array.flatten<Transaction>([_transactions, [tx]]);
    id;
  };

  // ============================================================
  // PROPOSAL HELPERS
  // ============================================================

  func findProposal(id : Nat) : ?Proposal {
    Array.find<Proposal>(_proposals, func(p : Proposal) : Bool { p.id == id });
  };

  /// Check quorum + majority using token-weighted voting.
  /// Quorum is based on total voting power, not headcount.
  func evaluateProposal(proposal : Proposal) : ProposalStatus {
    if (proposal.status != #active) { return proposal.status; };

    let totalVotes = proposal.votesFor + proposal.votesAgainst;

    // Has voting deadline passed?
    if (Time.now() >= proposal.votingDeadline) {
      // Deadline reached — check token-weight majority
      // Simple majority: votesFor > votesAgainst
      if (totalVotes > 0 and proposal.votesFor * MAJORITY_DENOMINATOR > totalVotes * MAJORITY_NUMERATOR) {
        return #passed;
      } else {
        return #rejected;
      };
    };

    // Still within voting window — can pass early if votesFor > votesAgainst
    // and at least quorum fraction of total possible voting power has voted.
    // For simplicity: remain active until deadline or unanimous.
    #active;
  };

  /// Replace a proposal in the stable array by id.
  func updateProposal(updated : Proposal) : () {
    _proposals := Array.map<Proposal, Proposal>(
      _proposals,
      func(p : Proposal) : Proposal { if (p.id == updated.id) { updated } else { p } }
    );
  };

  // ============================================================
  // DAO TOKEN HELPERS
  // ============================================================

  /// Get the ICRC-1 ledger actor (lazy init).
  func getLedgerActor() : Icrc1LedgerActor {
    switch (_tokenLedgerCanisterId) {
      case (?id) { actor (id) : Icrc1LedgerActor };
      case null { throw Error.reject("500: token ledger canister ID not configured"); };
    };
  };

  /// Get the token balance for a principal from the ICRC-1 ledger.
  func getTokenBalance(p : Principal) : async Nat {
    try {
      let ledger = getLedgerActor();
      let account : Account = { owner = p; subaccount = null };
      await ledger.icrc1_balance_of(account);
    } catch (_) { 0 };
  };

  /// Compute voting power = token_balance + staked_balance.
  func getVotingPower(p : Principal) : async Nat {
    let balance = await getTokenBalance(p);
    let staked = getStakedBalanceFor(p);
    balance + staked;
  };

  /// Check if a principal has already been airdropped.
  func hasBeenAirdropped(p : Principal) : Bool {
    Option.isSome(Array.find<Principal>(_airdropped, func(a : Principal) : Bool { a == p }));
  };

  // ============================================================
  // STAKING HELPERS
  // ============================================================

  /// Find a stake position by principal.
  func findStake(p : Principal) : ?StakePosition {
    switch (Array.find<(Principal, StakePosition)>(_stakes, func(e : (Principal, StakePosition)) : Bool { e.0 == p })) {
      case (?(_, stake)) { ?stake };
      case null { null };
    };
  };

  /// Get staked balance for a principal (0 if none).
  func getStakedBalanceFor(p : Principal) : Nat {
    switch (findStake(p)) {
      case (?s) { s.amount };
      case null { 0 };
    };
  };

  /// Compute pending staking rewards since last claim.
  func computeRewards(stake : StakePosition) : Nat {
    let now = Time.now();
    if (stake.amount == 0 or now <= stake.rewardedAt) { return 0 };

    // Simple linear reward: amount * APY * (time_elapsed / year)
    let elapsedNs = now - stake.rewardedAt;
    let yearNs : Int = 365 * 24 * 60 * 60 * 1_000_000_000;
    // rewards = amount * (APY_BPS / 10000) * (elapsed / year)
    let numerator : Nat = stake.amount * STAKING_APY_BPS * Nat.abs(elapsedNs);
    let denominator : Nat = 10000 * Nat.abs(yearNs);
    if (denominator == 0) { 0 } else { numerator / denominator };
  };

  /// Check whether a principal qualifies for fee discount.
  func hasFeeDiscount(p : Principal) : async Bool {
    let balance = await getTokenBalance(p);
    let staked = getStakedBalanceFor(p);
    (balance + staked) >= FEE_DISCOUNT_THRESHOLD;
  };

  /// Calculate the effective fee for a payment in basis points.
  func effectiveFeeBps(p : Principal) : async Nat {
    if (await hasFeeDiscount(p)) {
      let discount = (DEFAULT_FEE_BPS * FEE_DISCOUNT_BPS) / 10000;
      if (discount >= DEFAULT_FEE_BPS) { 0 } else { DEFAULT_FEE_BPS - discount };
    } else {
      DEFAULT_FEE_BPS;
    };
  };

  /// Update a stake position in the stable array.
  func upsertStake(stake : StakePosition) : () {
    var found : Bool = false;
    _stakes := Array.map<(Principal, StakePosition), (Principal, StakePosition)>(
      _stakes,
      func(e : (Principal, StakePosition)) : (Principal, StakePosition) {
        if (e.0 == stake.principal) { found := true; (stake.principal, stake) } else { e }
      }
    );
    if (not found) {
      _stakes := Array.flatten<(Principal, StakePosition)>([_stakes, [(stake.principal, stake)]]);
    };
  };

  // ============================================================
  // QUERY METHODS — BALANCES
  // ============================================================

  /// Get the balance of a specific token for a given member principal.
  public query func getBalance(p : Principal, token : TokenSymbol) : async Nat {
    lookupBalance(p, token);
  };

  /// Get all token balances for a given member principal.
  public query func getBalances(p : Principal) : async [BalanceEntry] {
    switch (Array.find<(Principal, [(TokenSymbol, Nat)])>(
      _balances,
      func(entry : (Principal, [(TokenSymbol, Nat)])) : Bool { entry.0 == p }
    )) {
      case (?(_, tokenEntries)) {
        Array.map<(TokenSymbol, Nat), BalanceEntry>(tokenEntries, func(t : (TokenSymbol, Nat)) : BalanceEntry {
          { token = t.0; amount = t.1 }
        });
      };
      case null { [] };
    };
  };

  /// Get all balances across every member (admin-level overview).
  public query func getAllBalances() : async [(Principal, [BalanceEntry])] {
    Array.map<(Principal, [(TokenSymbol, Nat)]), (Principal, [BalanceEntry])>(
      _balances,
      func(entry : (Principal, [(TokenSymbol, Nat)])) : (Principal, [BalanceEntry]) {
        let (p, tokens) = entry;
        (p, Array.map<(TokenSymbol, Nat), BalanceEntry>(tokens, func(t : (TokenSymbol, Nat)) : BalanceEntry {
          { token = t.0; amount = t.1 }
        }))
      }
    );
  };

  // ============================================================
  // QUERY METHODS — TRANSACTIONS
  // ============================================================

  /// Get full transaction history. limit=0 returns all, otherwise
  /// returns the most recent `limit` entries.
  public query func getTransactions(limit : Nat) : async [Transaction] {
    let all = _transactions;
    if (limit == 0 or limit >= all.size()) {
      all;
    } else {
      let start = all.size() - limit;
      Array.tabulate<Transaction>(limit, func(i : Nat) : Transaction { all[start + i] });
    };
  };

  /// Get transactions involving a specific principal.
  public query func getTransactionsByPrincipal(p : Principal, limit : Nat) : async [Transaction] {
    let filtered = Array.filter<Transaction>(_transactions, func(tx : Transaction) : Bool {
      tx.initiator == p or tx.fromPrincipal == p or Option.equal(tx.toPrincipal, ?p, Principal.equal)
    });
    if (limit == 0 or limit >= filtered.size()) {
      filtered;
    } else {
      let start = filtered.size() - limit;
      Array.tabulate<Transaction>(limit, func(i : Nat) : Transaction { filtered[start + i] });
    };
  };

  /// Get a single transaction by id.
  public query func getTransaction(id : Nat) : async ?Transaction {
    Array.find<Transaction>(_transactions, func(tx : Transaction) : Bool { tx.id == id });
  };

  // ============================================================
  // QUERY METHODS — MEMBERS
  // ============================================================

  /// List all DAO members.
  public query func getMembers() : async [MemberInfo] {
    Array.map<Member, MemberInfo>(_members, func(m : Member) : MemberInfo {
      { principal = m.principal; role = m.role; name = m.name; joinedAt = m.joinedAt }
    });
  };

  /// Look up a single member by principal.
  public query func getMember(p : Principal) : async ?MemberInfo {
    switch (findMember(p)) {
      case (?m) { ?{ principal = m.principal; role = m.role; name = m.name; joinedAt = m.joinedAt } };
      case null { null };
    };
  };

  /// Check whether a principal is a member.
  public query func checkMembership(p : Principal) : async Bool {
    isMember(p);
  };

  // ============================================================
  // QUERY METHODS — PROPOSALS
  // ============================================================

  /// List all proposals, newest first.
  public query func getProposals() : async [Proposal] {
    let sorted = Array.sort<Proposal>(_proposals, func(a : Proposal, b : Proposal) : {#less; #equal; #greater} {
      if (a.id > b.id) { #less } else if (a.id < b.id) { #greater } else { #equal }
    });
    sorted;
  };

  /// Get a single proposal by id.
  public query func getProposal(id : Nat) : async ?Proposal {
    findProposal(id);
  };

  /// List proposals filtered by status.
  public query func getProposalsByStatus(status : ProposalStatus) : async [Proposal] {
    Array.filter<Proposal>(_proposals, func(p : Proposal) : Bool { p.status == status });
  };

  // ============================================================
  // QUERY METHODS — STATS
  // ============================================================

  /// Aggregate dashboard statistics.
  public type Stats = {
    totalMembers : Nat;
    activeProposals : Nat;
    totalTransactions : Nat;
    tokenCount : Nat;
  };

  /// Get dashboard-level statistics for the DAO.
  public query func getStats() : async Stats {
    let now = Time.now();
    let activeCount = Array.foldLeft<Proposal, Nat>(
      _proposals, 0,
      func(acc : Nat, p : Proposal) : Nat {
        if (p.status == #active and p.votingDeadline > now) { acc + 1 } else { acc }
      }
    );
    {
      totalMembers = _members.size();
      activeProposals = activeCount;
      totalTransactions = _transactions.size();
      tokenCount = 0;  // placeholder — set via ICRC-1 ledger once configured
    };
  };

  // ============================================================
  // UPDATE — MEMBER MANAGEMENT (admin only)
  // ============================================================

  /// Bootstrap: initialise the DAO with the caller as the first admin.
  /// Only succeeds when there are zero members.
  public shared(msg) func initialize(name : Text) : async MemberInfo {
    if (_members.size() != 0) {
      throw Error.reject("400: DAO already initialized — " # Nat.toText(_members.size()) # " member(s) exist");
    };
    let caller = msg.caller;
    let member : Member = {
      principal = caller;
      role = #admin;
      name;
      joinedAt = Time.now();
    };
    _members := [member];
    { principal = member.principal; role = member.role; name = member.name; joinedAt = member.joinedAt }
  };

  /// Admin adds a new member.
  public shared(msg) func addMember(p : Principal, name : Text) : async MemberInfo {
    let caller = msg.caller;
    requireAdmin(caller);

    if (isMember(p)) {
      throw Error.reject("400: principal " # Principal.toText(p) # " is already a member");
    };

    let member : Member = {
      principal = p;
      role = #member;
      name;
      joinedAt = Time.now();
    };
    _members := Array.flatten<Member>([_members, [member]]);

    { principal = member.principal; role = member.role; name = member.name; joinedAt = member.joinedAt }
  };

  /// Admin removes a member. Cannot remove the last admin.
  public shared(msg) func removeMember(p : Principal) : async Bool {
    let caller = msg.caller;
    requireAdmin(caller);

    // Prevent removing the last admin
    let adminCount = Array.foldLeft<Member, Nat>(_members, 0, func(acc : Nat, m : Member) : Nat {
      if (m.role == #admin) { acc + 1 } else { acc }
    });
    switch (findMember(p)) {
      case (?m) {
        if (m.role == #admin and adminCount <= 1) {
          throw Error.reject("400: cannot remove the last admin");
        };
      };
      case null {
        throw Error.reject("404: member not found — " # Principal.toText(p));
      };
    };

    _members := Array.filter<Member>(_members, func(m : Member) : Bool { m.principal != p });
    true;
  };

  /// Admin promotes a member to admin.
  public shared(msg) func promoteToAdmin(p : Principal) : async Bool {
    let caller = msg.caller;
    requireAdmin(caller);

    if (not isMember(p)) {
      throw Error.reject("404: member not found — " # Principal.toText(p));
    };

    _members := Array.map<Member, Member>(_members, func(m : Member) : Member {
      if (m.principal == p) { { m with role = #admin } } else { m }
    });
    true;
  };

  // ============================================================
  // UPDATE — DEPOSITS (admin only)
  // ============================================================

  /// Admin records an external deposit credited to the DAO treasury.
  /// Increases the member's balance for the given token.
  public shared(msg) func recordDeposit(
    memberPrincipal : Principal,
    token : TokenSymbol,
    amount : Nat,
    description : Text,
  ) : async Nat {
    let caller = msg.caller;
    requireAdmin(caller);

    if (not isMember(memberPrincipal)) {
      throw Error.reject("404: recipient is not a DAO member — " # Principal.toText(memberPrincipal));
    };

    addBalance(memberPrincipal, token, amount);

    let txId = logTransaction(
      caller,
      /* from */ memberPrincipal,
      /* to */ null,
      /* toAddress */ null,
      token,
      amount,
      #deposit,
      #completed,
      description,
    );

    txId;
  };

  // ============================================================
  // UPDATE — PAYMENTS (member-initiated)
  // ============================================================

  /// A member requests a payment from their own treasury balance.
  /// Deducts from the caller's balance immediately.
  public shared(msg) func executePayment(
    token : TokenSymbol,
    amount : Nat,
    toPrincipal : ?Principal,
    toAddress : ?Text,
    description : Text,
  ) : async Nat {
    let caller = msg.caller;
    requireMember(caller);

    // Validate that at least one destination is provided
    if (Option.isNull(toPrincipal) and Option.isNull(toAddress)) {
      throw Error.reject("400: must provide either toPrincipal or toAddress");
    };

    // Check sufficient balance
    let current = lookupBalance(caller, token);
    if (current < amount) {
      throw Error.reject("400: insufficient balance — have " # Nat.toText(current) # ", need " # Nat.toText(amount));
    };

    subtractBalance(caller, token, amount);

    let txId = logTransaction(
      caller,
      /* from */ caller,
      toPrincipal,
      toAddress,
      token,
      amount,
      #payment,
      #completed,
      description,
    );

    txId;
  };

  // ============================================================
  // UPDATE — PROPOSALS (member-initiated)
  // ============================================================

  /// Create a new governance proposal. For payment proposals include
  /// token, amount, and recipient; for non-payment proposals set amount=0.
  public shared(msg) func createProposal(
    title : Text,
    description : Text,
    token : TokenSymbol,
    amount : Nat,
    recipient : ?Principal,
  ) : async Proposal {
    let caller = msg.caller;
    requireMember(caller);

    let id = _nextProposalId;
    _nextProposalId += 1;

    let now = Time.now();
    let proposal : Proposal = {
      id;
      proposer = caller;
      title;
      description;
      token;
      amount;
      recipient;
      status = #active;
      votesFor = 0;
      votesAgainst = 0;
      voters = [];
      createdAt = now;
      votingDeadline = now + VOTING_PERIOD_NS;
      executedAt = null;
    };

    _proposals := Array.flatten<Proposal>([_proposals, [proposal]]);
    proposal;
  };

  /// Cast a vote on an active proposal. Voting power = token_balance + staked_balance.
  /// One member can only vote once per proposal.
  public shared(msg) func voteOnProposal(proposalId : Nat, vote : VoteChoice) : async Proposal {
    let caller = msg.caller;
    requireMember(caller);

    switch (findProposal(proposalId)) {
      case null {
        throw Error.reject("404: proposal not found — id " # Nat.toText(proposalId));
      };
      case (?proposal) {
        if (proposal.status != #active) {
          throw Error.reject("400: proposal is not active — current status: " # debug_show(proposal.status));
        };

        // Prevent double voting
        if (Array.find<Principal>(proposal.voters, func(v : Principal) : Bool { v == caller }) != null) {
          throw Error.reject("400: caller already voted on proposal " # Nat.toText(proposalId));
        };

        // Compute voting power (token balance + staked balance)
        let power = await getVotingPower(caller);
        if (power < MIN_VOTING_TOKENS) {
          throw Error.reject("400: insufficient voting power — have " # Nat.toText(power) # ", need at least " # Nat.toText(MIN_VOTING_TOKENS));
        };

        let updatedVoters = Array.flatten<Principal>([proposal.voters, [caller]]);
        var updated : Proposal = { proposal with voters = updatedVoters };

        switch (vote) {
          case (#for_)    { updated := { updated with votesFor    = updated.votesFor + power    } };
          case (#against) { updated := { updated with votesAgainst = updated.votesAgainst + power } };
        };

        // Evaluate whether the proposal should pass/reject
        let newStatus = evaluateProposal(updated);
        updated := { updated with status = newStatus };

        updateProposal(updated);
        updated;
      };
    };
  };

  /// Admin or proposer cancels an active proposal.
  public shared(msg) func cancelProposal(proposalId : Nat) : async Proposal {
    let caller = msg.caller;

    switch (findProposal(proposalId)) {
      case null {
        throw Error.reject("404: proposal not found — id " # Nat.toText(proposalId));
      };
      case (?proposal) {
        if (proposal.status != #active) {
          throw Error.reject("400: proposal is not active");
        };
        // Only the proposer or an admin may cancel
        if (caller != proposal.proposer and not isAdmin(caller)) {
          throw Error.reject("403: only the proposer or an admin may cancel a proposal");
        };

        let updated : Proposal = { proposal with status = #cancelled };
        updateProposal(updated);
        updated;
      };
    };
  };

  /// Admin executes a passed proposal. For payment proposals the
  /// proposer's balance must cover the requested amount.
  public shared(msg) func executeProposal(proposalId : Nat) : async Proposal {
    let caller = msg.caller;
    requireAdmin(caller);

    switch (findProposal(proposalId)) {
      case null {
        throw Error.reject("404: proposal not found — id " # Nat.toText(proposalId));
      };
      case (?proposal) {
        if (proposal.status != #passed) {
          throw Error.reject("400: proposal must be in #passed status to execute — current: " # debug_show(proposal.status));
        };

        // If this is a payment proposal, attempt the transfer
        if (proposal.amount > 0) {
          switch (proposal.recipient) {
            case (?recipientPrincipal) {
              // Transfer from proposer's balance to recipient
              let proposerBalance = lookupBalance(proposal.proposer, proposal.token);
              if (proposerBalance < proposal.amount) {
                throw Error.reject("400: proposer has insufficient balance — have " # Nat.toText(proposerBalance) # ", need " # Nat.toText(proposal.amount));
              };

              subtractBalance(proposal.proposer, proposal.token, proposal.amount);
              addBalance(recipientPrincipal, proposal.token, proposal.amount);

              ignore logTransaction(
                caller,
                proposal.proposer,
                proposal.recipient,
                null,
                proposal.token,
                proposal.amount,
                #payment,
                #completed,
                "Proposal #" # Nat.toText(proposal.id) # ": " # proposal.title,
              );
            };
            case null {
              // Payment proposal without a recipient — treat as withdrawal
              subtractBalance(proposal.proposer, proposal.token, proposal.amount);

              ignore logTransaction(
                caller,
                proposal.proposer,
                null,
                null,
                proposal.token,
                proposal.amount,
                #withdrawal,
                #completed,
                "Proposal #" # Nat.toText(proposal.id) # ": " # proposal.title,
              );
            };
          };
        };

        let updated : Proposal = { proposal with status = #executed; executedAt = ?Time.now() };
        updateProposal(updated);
        updated;
      };
    };
  };

  // ============================================================
  // UPGRADE HOOKS
  // ============================================================

  system func preupgrade() { };

  system func postupgrade() { };

};