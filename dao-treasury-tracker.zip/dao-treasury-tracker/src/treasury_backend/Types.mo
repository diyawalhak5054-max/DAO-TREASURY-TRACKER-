// Types.mo
// Shared data model for the DAO Treasury Tracker canister.
// Kept in its own module so both main.mo and any future modules can import it.

import Principal "mo:base/Principal";
import Time "mo:base/Time";

module {

  // ---- Roles -------------------------------------------------------------
  // Admin      : full control — members, config, multisig threshold, proposals
  // Treasurer  : can send ICP and create/approve proposals
  // Member     : read-only access to dashboard / history
  public type Role = {
    #Admin;
    #Treasurer;
    #Member;
  };

  public type Member = {
    principal : Principal;
    name : Text;
    role : Role;
    addedAt : Time.Time;
  };

  public type TransactionStatus = {
    #Pending;    // waiting on multisig approval
    #Completed;  // executed on the ICP ledger
    #Rejected;   // multisig rejected
    #Failed;     // ledger call failed
  };

  public type Transaction = {
    id : Nat;
    date : Time.Time;
    from : Text;          // account identifier (hex) of the treasury subaccount
    to : Text;             // destination account identifier (hex)
    amountE8s : Nat64;      // amount in e8s (1 ICP = 100_000_000 e8s)
    memo : Nat64;
    status : TransactionStatus;
    blockHeight : ?Nat64;   // set once the ledger confirms the transfer
    initiatedBy : Principal;
    proposalId : ?Nat;      // set if this transaction came from a multisig proposal
  };

  public type ProposalStatus = {
    #Open;
    #Approved;
    #Rejected;
    #Executed;
  };

  public type Proposal = {
    id : Nat;
    to : Text;
    amountE8s : Nat64;
    memo : Nat64;
    description : Text;
    createdBy : Principal;
    createdAt : Time.Time;
    approvals : [Principal];
    rejections : [Principal];
    status : ProposalStatus;
    requiredApprovals : Nat;
  };

  public type TreasuryConfig = {
    daoName : Text;
    multisigThresholdE8s : Nat64; // transactions >= this amount require multisig
    requiredApprovals : Nat;      // number of Treasurer/Admin approvals needed
    treasurySubaccount : ?Blob;   // optional ICP subaccount used by this DAO
  };

  // Public-facing summary used by the dashboard so the frontend doesn't need
  // to make several separate calls.
  public type DashboardSummary = {
    balanceE8s : Nat64;
    memberCount : Nat;
    pendingProposals : Nat;
    totalTransactions : Nat;
    config : TreasuryConfig;
  };

  public type ApiError = {
    #NotAuthorized;
    #NotFound;
    #InvalidInput : Text;
    #LedgerError : Text;
  };

  public type Result<T> = {
    #ok : T;
    #err : ApiError;
  };
}
