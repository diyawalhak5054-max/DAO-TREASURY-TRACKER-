// Ledger.mo
// Minimal interface to the standard ICP Ledger canister (ryjl3-tyaaa-aaaaa-aaaba-cai on mainnet).
// Only the methods this dapp actually calls are declared here — this keeps the
// candid surface small and avoids depending on any external/off-chain API.

module {

  public type AccountIdentifier = Blob;

  public type ICPTs = {
    e8s : Nat64;
  };

  public type AccountBalanceArgs = {
    account : AccountIdentifier;
  };

  public type TimeStamp = {
    timestamp_nanos : Nat64;
  };

  public type Memo = Nat64;

  public type TransferArgs = {
    memo : Memo;
    amount : ICPTs;
    fee : ICPTs;
    from_subaccount : ?Blob;
    to : AccountIdentifier;
    created_at_time : ?TimeStamp;
  };

  public type TransferError = {
    #BadFee : { expected_fee : ICPTs };
    #InsufficientFunds : { balance : ICPTs };
    #TxTooOld : { allowed_window_nanos : Nat64 };
    #TxCreatedInFuture;
    #TxDuplicate : { duplicate_of : Nat64 };
  };

  public type TransferResult = {
    #Ok : Nat64; // block height
    #Err : TransferError;
  };

  // Actor reference type — instantiate with `actor(canisterId) : Self` in main.mo
  public type Self = actor {
    account_balance : shared query (AccountBalanceArgs) -> async ICPTs;
    transfer : shared (TransferArgs) -> async TransferResult;
  };
}
