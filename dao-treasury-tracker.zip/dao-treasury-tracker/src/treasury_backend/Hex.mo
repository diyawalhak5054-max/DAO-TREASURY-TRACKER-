// Hex.mo
// Account identifiers on the ICP ledger are 32-byte blobs, normally shown to
// users as a 64-character hex string. Rather than reimplementing SHA-224 +
// CRC32 in Motoko (the algorithm used to derive an account id from a
// principal), the frontend computes account identifiers with the official
// @dfinity/ledger-icp helper and sends them to the canister as hex text.
// This module just converts that hex text to/from Blob.

import Nat8 "mo:base/Nat8";
import Nat32 "mo:base/Nat32";
import Char "mo:base/Char";
import Iter "mo:base/Iter";
import Buffer "mo:base/Buffer";
import Blob "mo:base/Blob";

module {

  // Converts a single hex character to its value (0-15), or null if invalid.
  func hexCharToNat8(c : Char) : ?Nat8 {
    let code : Nat32 = Char.toNat32(c);
    if (code >= 48 and code <= 57) {
      return ?Nat8.fromNat(Nat32.toNat(code - 48)); // '0'-'9'
    } else if (code >= 97 and code <= 102) {
      return ?Nat8.fromNat(Nat32.toNat(code - 87)); // 'a'-'f'
    } else if (code >= 65 and code <= 70) {
      return ?Nat8.fromNat(Nat32.toNat(code - 55)); // 'A'-'F'
    } else {
      return null;
    };
  };

  public func decode(hex : Text) : ?Blob {
    if (hex.size() % 2 != 0 or hex.size() == 0) return null;
    let chars = Iter.toArray(hex.chars());
    let buf = Buffer.Buffer<Nat8>(chars.size() / 2);
    var i = 0;
    while (i < chars.size()) {
      let hi = hexCharToNat8(chars[i]);
      let lo = hexCharToNat8(chars[i + 1]);
      switch (hi, lo) {
        case (?h, ?l) { buf.add(h * 16 + l) };
        case (_, _) { return null };
      };
      i += 2;
    };
    return ?Blob.fromArray(Buffer.toArray(buf));
  };

  public func encode(b : Blob) : Text {
    let hexDigits = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f"];
    var out = "";
    for (byte in Blob.toArray(b).vals()) {
      let hi = Nat8.toNat(byte / 16);
      let lo = Nat8.toNat(byte % 16);
      out #= hexDigits[hi] # hexDigits[lo];
    };
    return out;
  };
}
