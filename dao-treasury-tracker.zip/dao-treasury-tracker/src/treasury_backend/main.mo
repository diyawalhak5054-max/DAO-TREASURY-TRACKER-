// main.mo
// DAO Treasury Tracker — backend canister.
//
// Everything here runs fully on-chain: the only external canister this actor
// talks to is the standard ICP Ledger (no off-chain APIs of any kind), which
// satisfies the "plug-and-play / on-chain only" requirement.
//
// Upgrade safety: all mutable state lives in stable vars / stable arrays and
// is rebuilt into HashMaps in `postupgrade`, so `dfx deploy` upgrades never
// lose data.

import HashMap "mo:base/HashMap";
import Principal "mo:base/Principal";
import Array "mo:base/Array";
import Buffer "mo:base/Buffer";
import Time "mo:base/Time";
import Nat "mo:base/Nat";
import Nat64 "mo:base/Nat64";
import Text "mo:base/Text";
import Iter "mo:base/Iter";

import Types "./Types";
import Ledger "./Ledger";
import Hex "./Hex";

actor class TreasuryBackend() = this {

  // ---- Ledger wiring -------------------------------------------------------
  // Mainnet ICP ledger canister id. On local replicas this is overridden by
  // deploying/using the `icp_ledger` alias declared in dfx.json.
  let LEDGER_CANISTER_ID : Text = "ryjl3-tyaaa-aaaaa-aaaba-cai";
  let ledger : Ledger.Self = actor (LEDGER_CANISTER_ID);
  let DEFAULT_FEE_E8S : Nat64 = 10_000; // standard ICP ledger transfer fee

  // ---- Stable state ---------------------------------------------------------
  stable var membersStable : [(Principal, Types.Member)] = [];
  stable var transactionsStable : [Types.Transaction] = [];
  stable var proposalsStable : [Types.Proposal] = [];
  stable var nextTxId : Nat = 0;
  stable var nextProposalId : Nat = 0;
  stable var config : Types.TreasuryConfig = {
    daoName = "My DAO";
    multisigThresholdE8s = 100_000_000_000; // 1,000 ICP default threshold
    requiredApprovals = 2;
    treasurySubaccount = null;
  };
  // The first Admin is set on first call to `init` (deployer bootstraps
  // themself in). Empty until then.
  stable var initialized : Bool = false;

  // ---- Runtime (non-stable) maps, rebuilt on upgrade ------------------------
  var members = HashMap.HashMap<Principal, Types.Member>(0, Principal.equal, Principal.hash);

  system func preupgrade() {
    membersStable := Iter.toArray(members.entries());
  };

  system func postupgrade() {
    members := HashMap.fromIter<Principal, Types.Member>(membersStable.vals(), membersStable.size(), Principal.equal, Principal.hash);
  };

  // ---- Access control helpers -----------------------------------------------

  func getRole(p : Principal) : ?Types.Role {
    switch (members.get(p)) {
      case (?m) ?m.role;
      case null null;
    };
  };

  func isAdmin(p : Principal) : Bool {
    switch (getRole(p)) {
      case (?#Admin) true;
      case _ false;
    };
  };

  func isTreasurerOrAdmin(p : Principal) : Bool {
    switch (getRole(p)) {
      case (?#Admin) true;
      case (?#Treasurer) true;
      case _ false;
    };
  };

  func isMember(p : Principal) : Bool {
    switch (getRole(p)) {
      case (?_) true;
      case null false;
    };
  };

  // ---- Bootstrap --------------------------------------------------------
  // Called once, by the principal that deploys the canister (or the first
  // person to connect), to seed the first Admin. Safe to call repeatedly —
  // becomes a no-op once initialized.
  public shared (msg) func init(daoName : Text) : async Types.Result<Text> {
    if (initialized) {
      return #err(#InvalidInput("Treasury already initialized"));
    };
    let caller = msg.caller;
    members.put(caller, {
      principal = caller;
      name = "Founding Admin";
      role = #Admin;
      addedAt = Time.now();
    });
    config := { config with daoName = daoName };
    initialized := true;
    return #ok("Initialized");
  };

  public query func isInitialized() : async Bool { initialized };

  // ---- Member management (Admin only) ---------------------------------------

  public shared (msg) func addMember(p : Principal, name : Text, role : Types.Role) : async Types.Result<()> {
    if (not isAdmin(msg.caller)) return #err(#NotAuthorized);
    members.put(p, { principal = p; name = name; role = role; addedAt = Time.now() });
    return #ok(());
  };

  public shared (msg) func removeMember(p : Principal) : async Types.Result<()> {
    if (not isAdmin(msg.caller)) return #err(#NotAuthorized);
    if (Principal.equal(p, msg.caller)) {
      return #err(#InvalidInput("Cannot remove yourself"));
    };
    members.delete(p);
    return #ok(());
  };

  public shared (msg) func updateMemberRole(p : Principal, role : Types.Role) : async Types.Result<()> {
    if (not isAdmin(msg.caller)) return #err(#NotAuthorized);
    switch (members.get(p)) {
      case (?m) {
        members.put(p, { m with role = role });
        return #ok(());
      };
      case null return #err(#NotFound);
    };
  };

  public query func getMembers() : async [Types.Member] {
    Iter.toArray(members.vals());
  };

  public query (msg) func getMyRole() : async ?Types.Role {
    getRole(msg.caller);
  };

  // ---- Config (Admin only) ---------------------------------------------------

  public shared (msg) func updateConfig(newConfig : Types.TreasuryConfig) : async Types.Result<()> {
    if (not isAdmin(msg.caller)) return #err(#NotAuthorized);
    config := newConfig;
    return #ok(());
  };

  public query func getConfig() : async Types.TreasuryConfig {
    config;
  };

  // ---- Dashboard --------------------------------------------------------

  // Looks up the ICP balance for a given account identifier (hex text).
  // The frontend computes the treasury's own account id from this
  // canister's principal (via @dfinity/ledger-icp's AccountIdentifier
  // helper) and passes it in here — that keeps SHA-224/CRC32 account-id
  // derivation out of the canister entirely.
  public func getBalanceForAccount(accountHex : Text) : async Types.Result<Nat64> {
    switch (Hex.decode(accountHex)) {
      case null return #err(#InvalidInput("Invalid account hex"));
      case (?accBlob) {
        let balance = await ledger.account_balance({ account = accBlob });
        return #ok(balance.e8s);
      };
    };
  };

  public query func getDashboardCounts() : async { memberCount : Nat; pendingProposals : Nat; totalTransactions : Nat; config : Types.TreasuryConfig } {
    let pending = Array.filter<Types.Proposal>(proposalsStable, func(p) { p.status == #Open }).size();
    return {
      memberCount = members.size();
      pendingProposals = pending;
      totalTransactions = transactionsStable.size();
      config = config;
    };
  };

  // ---- Transactions -----------------------------------------------------

  public query func getTransactions() : async [Types.Transaction] {
    transactionsStable;
  };

  func addTransaction(t : Types.Transaction) {
    let buf = Buffer.fromArray<Types.Transaction>(transactionsStable);
    buf.add(t);
    transactionsStable := Buffer.toArray(buf);
  };

  func updateTransaction(id : Nat, updated : Types.Transaction) {
    transactionsStable := Array.map<Types.Transaction, Types.Transaction>(
      transactionsStable,
      func(t) { if (t.id == id) updated else t }
    );
  };

  // Executes an ICP transfer directly on the ledger and records the result.
  func executeTransfer(to : Text, amountE8s : Nat64, memo : Nat64, initiatedBy : Principal, proposalId : ?Nat) : async Types.Result<Types.Transaction> {
    switch (Hex.decode(to)) {
      case null return #err(#InvalidInput("Invalid destination account hex"));
      case (?toBlob) {
        let txId = nextTxId;
        nextTxId += 1;

        let pending : Types.Transaction = {
          id = txId;
          date = Time.now();
          from = "treasury";
          to = to;
          amountE8s = amountE8s;
          memo = memo;
          status = #Pending;
          blockHeight = null;
          initiatedBy = initiatedBy;
          proposalId = proposalId;
        };
        addTransaction(pending);

        let result = await ledger.transfer({
          memo = memo;
          amount = { e8s = amountE8s };
          fee = { e8s = DEFAULT_FEE_E8S };
          from_subaccount = config.treasurySubaccount;
          to = toBlob;
          created_at_time = null;
        });

        switch (result) {
          case (#Ok(blockHeight)) {
            let completed = { pending with status = #Completed; blockHeight = ?blockHeight };
            updateTransaction(txId, completed);
            return #ok(completed);
          };
          case (#Err(_)) {
            let failed = { pending with status = #Failed };
            updateTransaction(txId, failed);
            return #err(#LedgerError("Ledger transfer failed"));
          };
        };
      };
    };
  };

  // Send ICP. If the amount is below the multisig threshold, it executes
  // immediately (Treasurer/Admin only). Otherwise it creates a Proposal
  // instead of transferring funds right away.
  public shared (msg) func sendICP(to : Text, amountE8s : Nat64, memo : Nat64, description : Text) : async Types.Result<Text> {
    if (not isTreasurerOrAdmin(msg.caller)) return #err(#NotAuthorized);

    if (amountE8s >= config.multisigThresholdE8s) {
      let pid = nextProposalId;
      nextProposalId += 1;
      let proposal : Types.Proposal = {
        id = pid;
        to = to;
        amountE8s = amountE8s;
        memo = memo;
        description = description;
        createdBy = msg.caller;
        createdAt = Time.now();
        approvals = [msg.caller]; // proposer counts as first approval
        rejections = [];
        status = #Open;
        requiredApprovals = config.requiredApprovals;
      };
      let buf = Buffer.fromArray<Types.Proposal>(proposalsStable);
      buf.add(proposal);
      proposalsStable := Buffer.toArray(buf);
      return #ok("Amount exceeds multisig threshold — proposal #" # Nat.toText(pid) # " created, awaiting approval");
    };

    let result = await executeTransfer(to, amountE8s, memo, msg.caller, null);
    switch (result) {
      case (#ok(_)) return #ok("Transfer completed");
      case (#err(e)) return #err(e);
    };
  };

  // ---- Multisig proposals -------------------------------------------------

  public query func getProposals() : async [Types.Proposal] {
    proposalsStable;
  };

  func findProposal(id : Nat) : ?Types.Proposal {
    Array.find<Types.Proposal>(proposalsStable, func(p) { p.id == id });
  };

  func replaceProposal(updated : Types.Proposal) {
    proposalsStable := Array.map<Types.Proposal, Types.Proposal>(
      proposalsStable,
      func(p) { if (p.id == updated.id) updated else p }
    );
  };

  func containsPrincipal(arr : [Principal], p : Principal) : Bool {
    switch (Array.find<Principal>(arr, func(x) { Principal.equal(x, p) })) {
      case (?_) true;
      case null false;
    };
  };

  public shared (msg) func approveProposal(id : Nat) : async Types.Result<Text> {
    if (not isTreasurerOrAdmin(msg.caller)) return #err(#NotAuthorized);
    switch (findProposal(id)) {
      case null return #err(#NotFound);
      case (?p) {
        if (p.status != #Open) return #err(#InvalidInput("Proposal is not open"));
        if (containsPrincipal(p.approvals, msg.caller)) {
          return #err(#InvalidInput("Already approved"));
        };
        let buf = Buffer.fromArray<Principal>(p.approvals);
        buf.add(msg.caller);
        let newApprovals = Buffer.toArray(buf);
        let updated = { p with approvals = newApprovals };
        replaceProposal(updated);

        if (newApprovals.size() >= p.requiredApprovals) {
          let executed = { updated with status = #Executed };
          replaceProposal(executed);
          let _ = await executeTransfer(p.to, p.amountE8s, p.memo, p.createdBy, ?p.id);
          return #ok("Threshold met — transfer executed");
        };
        return #ok("Approval recorded (" # Nat.toText(newApprovals.size()) # "/" # Nat.toText(p.requiredApprovals) # ")");
      };
    };
  };

  public shared (msg) func rejectProposal(id : Nat) : async Types.Result<Text> {
    if (not isTreasurerOrAdmin(msg.caller)) return #err(#NotAuthorized);
    switch (findProposal(id)) {
      case null return #err(#NotFound);
      case (?p) {
        if (p.status != #Open) return #err(#InvalidInput("Proposal is not open"));
        let buf = Buffer.fromArray<Principal>(p.rejections);
        buf.add(msg.caller);
        let updated = { p with rejections = Buffer.toArray(buf); status = #Rejected };
        replaceProposal(updated);
        return #ok("Proposal rejected");
      };
    };
  };

  // Lets any member log a deposit they made themselves (e.g. via an
  // external wallet payment) into the treasury's transaction history.
  // Unlike importTransactionRecord (Admin-only, for bulk historical
  // imports), this is self-service bookkeeping: it doesn't move funds —
  // the transfer already happened elsewhere — it just records it.
  public shared (msg) func recordDeposit(amountE8s : Nat64, memo : Nat64, note : Text) : async Types.Result<()> {
    if (not isMember(msg.caller)) return #err(#NotAuthorized);
    let txId = nextTxId;
    nextTxId += 1;
    let callerText = Principal.toText(msg.caller);
    let fromLabel = if (note != "") { callerText # " (" # note # ")" } else { callerText };
    addTransaction({
      id = txId;
      date = Time.now();
      from = fromLabel;
      to = "treasury";
      amountE8s = amountE8s;
      memo = memo;
      status = #Completed;
      blockHeight = null;
      initiatedBy = msg.caller;
      proposalId = null;
    });
    return #ok(());
  };

  // ---- CSV export / import (Admin/Treasurer for import) --------------------

  public query func exportTransactionsCSV() : async Text {
    var csv = "id,date,from,to,amountE8s,memo,status,blockHeight\n";
    for (t in transactionsStable.vals()) {
      let status = switch (t.status) {
        case (#Pending) "Pending";
        case (#Completed) "Completed";
        case (#Rejected) "Rejected";
        case (#Failed) "Failed";
      };
      let bh = switch (t.blockHeight) {
        case (?b) Nat64.toText(b);
        case null "";
      };
      csv #= Nat.toText(t.id) # "," # Text.replace(t.from, #text(","), ";") # "," # t.to # "," # Nat64.toText(t.amountE8s) # "," # Nat64.toText(t.memo) # "," # status # "," # bh # "\n";
    };
    return csv;
  };

  // Imports historical/off-chain records for bookkeeping purposes only —
  // these are stored as already-#Completed rows for record-keeping and do
  // NOT trigger a real ledger transfer (that only ever happens via sendICP /
  // approveProposal). Useful for migrating history from another tool.
  public shared (msg) func importTransactionRecord(date : Int, from : Text, to : Text, amountE8s : Nat64, memo : Nat64, blockHeight : ?Nat64) : async Types.Result<()> {
    if (not isAdmin(msg.caller)) return #err(#NotAuthorized);
    let txId = nextTxId;
    nextTxId += 1;
    addTransaction({
      id = txId;
      date = date;
      from = from;
      to = to;
      amountE8s = amountE8s;
      memo = memo;
      status = #Completed;
      blockHeight = blockHeight;
      initiatedBy = msg.caller;
      proposalId = null;
    });
    return #ok(());
  };
};
