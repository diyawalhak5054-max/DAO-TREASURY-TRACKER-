/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        // Delta Ecosystem brand palette — dark blue + white.
        delta: {
          50: "#eef3fb",
          100: "#d7e3f6",
          200: "#aec7ed",
          300: "#7ea6e0",
          400: "#4f7fce",
          500: "#2f5fb3",
          600: "#1f4590",
          700: "#183872",
          800: "#122a54", // primary dark blue
          900: "#0a1830", // deepest navy
          950: "#050d1a",
        },
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};
