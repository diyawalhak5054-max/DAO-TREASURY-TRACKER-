// AuthContext.tsx
// Provides authentication state (Internet Identity or Delta Wallet) to the
// whole app, plus the treasury_backend actor bound to the connected identity.
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { Identity } from "@dfinity/agent";
import { Principal } from "@dfinity/principal";
import { ActorSubclass } from "@dfinity/agent";
import { TreasuryBackend, Role } from "../declarations/treasury_backend";
import { buildTreasuryActor } from "../lib/actors";
import { WalletAdapter, walletAdapters } from "./walletAdapter";

interface AuthContextValue {
  identity: Identity | null;
  principal: Principal | null;
  actor: ActorSubclass<TreasuryBackend> | null;
  role: Role | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  availableWallets: WalletAdapter[];
  connect: (walletId: WalletAdapter["id"]) => Promise<void>;
  disconnect: () => Promise<void>;
  refreshRole: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [identity, setIdentity] = useState<Identity | null>(null);
  const [actor, setActor] = useState<ActorSubclass<TreasuryBackend> | null>(null);
  const [role, setRole] = useState<Role | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeWalletId, setActiveWalletId] = useState<WalletAdapter["id"] | null>(null);

  const refreshRole = useCallback(async (currentActor?: ActorSubclass<TreasuryBackend> | null) => {
    const a = currentActor ?? actor;
    if (!a) {
      setRole(null);
      return;
    }
    try {
      const result = await a.getMyRole();
      setRole(result.length > 0 ? result[0] : null);
    } catch (err) {
      console.error("Failed to fetch role", err);
      setRole(null);
    }
  }, [actor]);

  const connect = useCallback(async (walletId: WalletAdapter["id"]) => {
    const adapter = walletAdapters.find((w) => w.id === walletId);
    if (!adapter) throw new Error(`Unknown wallet: ${walletId}`);
    const newIdentity = await adapter.connect();
    setIdentity(newIdentity);
    setActiveWalletId(walletId);
    const newActor = await buildTreasuryActor(newIdentity);
    setActor(newActor);
    await refreshRole(newActor);
  }, [refreshRole]);

  const disconnect = useCallback(async () => {
    const adapter = walletAdapters.find((w) => w.id === activeWalletId);
    if (adapter) await adapter.disconnect();
    setIdentity(null);
    setActor(null);
    setRole(null);
    setActiveWalletId(null);
  }, [activeWalletId]);

  // On first load, try to resume an existing Internet Identity session.
  useEffect(() => {
    (async () => {
      try {
        const ii = walletAdapters.find((w) => w.id === "internet-identity")!;
        // Attempting getIdentity() before connect() only resumes a session
        // that AuthClient already has cached (e.g. from a previous visit).
        const cached = ii.getIdentity();
        if (cached && !cached.getPrincipal().isAnonymous()) {
          setIdentity(cached);
          setActiveWalletId("internet-identity");
          const newActor = await buildTreasuryActor(cached);
          setActor(newActor);
          await refreshRole(newActor);
        }
      } finally {
        setIsLoading(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({
      identity,
      principal: identity?.getPrincipal() ?? null,
      actor,
      role,
      isAuthenticated: !!identity && !identity.getPrincipal().isAnonymous(),
      isLoading,
      availableWallets: walletAdapters,
      connect,
      disconnect,
      refreshRole: () => refreshRole(),
    }),
    [identity, actor, role, isLoading, connect, disconnect, refreshRole]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}

/** Convenience helper for checking a Role value against a target name. */
export function roleIs(role: Role | null, target: "Admin" | "Treasurer" | "Member"): boolean {
  if (!role) return false;
  return target in role;
}
