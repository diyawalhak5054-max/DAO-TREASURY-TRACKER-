// treasury_backend.did.js
// Hand-written idlFactory mirroring src/treasury_backend/treasury_backend.did.
// Run `dfx generate` after your first deploy to regenerate this file
// automatically from the live canister — keep it in sync if you change main.mo.
export const idlFactory = ({ IDL }) => {
  const Role = IDL.Variant({ Admin: IDL.Null, Treasurer: IDL.Null, Member: IDL.Null });

  const Member = IDL.Record({
    principal: IDL.Principal,
    name: IDL.Text,
    role: Role,
    addedAt: IDL.Int,
  });

  const TransactionStatus = IDL.Variant({
    Pending: IDL.Null,
    Completed: IDL.Null,
    Rejected: IDL.Null,
    Failed: IDL.Null,
  });

  const Transaction = IDL.Record({
    id: IDL.Nat,
    date: IDL.Int,
    from: IDL.Text,
    to: IDL.Text,
    amountE8s: IDL.Nat64,
    memo: IDL.Nat64,
    status: TransactionStatus,
    blockHeight: IDL.Opt(IDL.Nat64),
    initiatedBy: IDL.Principal,
    proposalId: IDL.Opt(IDL.Nat),
  });

  const ProposalStatus = IDL.Variant({
    Open: IDL.Null,
    Approved: IDL.Null,
    Rejected: IDL.Null,
    Executed: IDL.Null,
  });

  const Proposal = IDL.Record({
    id: IDL.Nat,
    to: IDL.Text,
    amountE8s: IDL.Nat64,
    memo: IDL.Nat64,
    description: IDL.Text,
    createdBy: IDL.Principal,
    createdAt: IDL.Int,
    approvals: IDL.Vec(IDL.Principal),
    rejections: IDL.Vec(IDL.Principal),
    status: ProposalStatus,
    requiredApprovals: IDL.Nat,
  });

  const TreasuryConfig = IDL.Record({
    daoName: IDL.Text,
    multisigThresholdE8s: IDL.Nat64,
    requiredApprovals: IDL.Nat,
    treasurySubaccount: IDL.Opt(IDL.Vec(IDL.Nat8)),
  });

  const ApiError = IDL.Variant({
    NotAuthorized: IDL.Null,
    NotFound: IDL.Null,
    InvalidInput: IDL.Text,
    LedgerError: IDL.Text,
  });

  const DashboardCounts = IDL.Record({
    memberCount: IDL.Nat,
    pendingProposals: IDL.Nat,
    totalTransactions: IDL.Nat,
    config: TreasuryConfig,
  });

  const ResultText = IDL.Variant({ ok: IDL.Text, err: ApiError });
  const ResultUnit = IDL.Variant({ ok: IDL.Null, err: ApiError });
  const ResultNat64 = IDL.Variant({ ok: IDL.Nat64, err: ApiError });

  return IDL.Service({
    init: IDL.Func([IDL.Text], [ResultText], []),
    isInitialized: IDL.Func([], [IDL.Bool], ["query"]),

    addMember: IDL.Func([IDL.Principal, IDL.Text, Role], [ResultUnit], []),
    removeMember: IDL.Func([IDL.Principal], [ResultUnit], []),
    updateMemberRole: IDL.Func([IDL.Principal, Role], [ResultUnit], []),
    getMembers: IDL.Func([], [IDL.Vec(Member)], ["query"]),
    getMyRole: IDL.Func([], [IDL.Opt(Role)], ["query"]),

    updateConfig: IDL.Func([TreasuryConfig], [ResultUnit], []),
    getConfig: IDL.Func([], [TreasuryConfig], ["query"]),

    getBalanceForAccount: IDL.Func([IDL.Text], [ResultNat64], []),
    getDashboardCounts: IDL.Func([], [DashboardCounts], ["query"]),

    getTransactions: IDL.Func([], [IDL.Vec(Transaction)], ["query"]),
    sendICP: IDL.Func([IDL.Text, IDL.Nat64, IDL.Nat64, IDL.Text], [ResultText], []),
    recordDeposit: IDL.Func([IDL.Nat64, IDL.Nat64, IDL.Text], [ResultUnit], []),

    getProposals: IDL.Func([], [IDL.Vec(Proposal)], ["query"]),
    approveProposal: IDL.Func([IDL.Nat], [ResultText], []),
    rejectProposal: IDL.Func([IDL.Nat], [ResultText], []),

    exportTransactionsCSV: IDL.Func([], [IDL.Text], ["query"]),
    importTransactionRecord: IDL.Func(
      [IDL.Int, IDL.Text, IDL.Text, IDL.Nat64, IDL.Nat64, IDL.Opt(IDL.Nat64)],
      [ResultUnit],
      []
    ),
  });
};

export const init = ({ IDL }) => [];
