import { ReactNode, useEffect, useState } from "react";
import { Wallet, Users, FileCheck2, ArrowLeftRight } from "lucide-react";
import { useAuth } from "../auth/AuthContext";
import { RoleBadge } from "../components/RoleBadge";
import { treasuryAccountHex } from "../lib/actors";
import { e8sToIcp, formatUsd } from "../lib/format";
import { DashboardCounts } from "../declarations/treasury_backend";

// No external price API is used (this dapp is fully on-chain / plug-and-play),
// so the ICP -> USD rate is a manually entered estimate, persisted locally.
function useIcpUsdRate(): [number, (v: number) => void] {
  const [rate, setRate] = useState<number>(() => {
    const stored = window.localStorage.getItem("icpUsdRate");
    return stored ? parseFloat(stored) : 10;
  });
  const update = (v: number) => {
    setRate(v);
    window.localStorage.setItem("icpUsdRate", String(v));
  };
  return [rate, update];
}

export function Dashboard() {
  const { actor, role, isAuthenticated } = useAuth();
  const [balanceE8s, setBalanceE8s] = useState<bigint | null>(null);
  const [counts, setCounts] = useState<DashboardCounts | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [icpUsdRate, setIcpUsdRate] = useIcpUsdRate();

  async function load() {
    if (!actor) return;
    setLoading(true);
    setError(null);
    try {
      const [balanceResult, dashboardCounts] = await Promise.all([
        actor.getBalanceForAccount(treasuryAccountHex()),
        actor.getDashboardCounts(),
      ]);
      if ("ok" in balanceResult) {
        setBalanceE8s(balanceResult.ok);
      } else {
        setError("Could not load balance from the ledger.");
      }
      setCounts(dashboardCounts);
    } catch (err) {
      console.error(err);
      setError("Failed to load treasury data.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [actor]);

  const icpAmount = balanceE8s !== null ? parseFloat(e8sToIcp(balanceE8s, 8)) : 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold">
            {counts?.config.daoName ?? "Treasury Dashboard"}
          </h1>
          <p className="text-sm text-delta-500 dark:text-delta-300">
            On-chain balance and activity overview.
          </p>
        </div>
        {isAuthenticated && <RoleBadge role={role} />}
      </div>

      {!isAuthenticated && (
        <div className="card text-sm text-delta-600 dark:text-delta-300">
          Connect with Internet Identity or Delta Wallet to see live treasury data and take action.
        </div>
      )}

      {error && (
        <div className="card border-rose-200 dark:border-rose-800 text-sm text-rose-600">{error}</div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="card">
          <div className="flex items-center gap-2 text-delta-500 dark:text-delta-300 text-xs font-medium uppercase tracking-wide">
            <Wallet size={14} /> Treasury Balance
          </div>
          <div className="mt-2 text-2xl font-bold">
            {loading ? "…" : `${e8sToIcp(balanceE8s ?? 0n)} ICP`}
          </div>
          <div className="mt-1 flex items-center justify-between text-xs text-delta-400">
            <span>≈ {formatUsd(icpAmount, icpUsdRate)}</span>
            <RateEditor rate={icpUsdRate} onChange={setIcpUsdRate} />
          </div>
        </div>

        <StatCard icon={<ArrowLeftRight size={14} />} label="Transactions" value={counts?.totalTransactions.toString() ?? "—"} />
        <StatCard icon={<FileCheck2 size={14} />} label="Pending Proposals" value={counts?.pendingProposals.toString() ?? "—"} />
        <StatCard icon={<Users size={14} />} label="Members" value={counts?.memberCount.toString() ?? "—"} />
      </div>

      {counts && (
        <div className="card">
          <h2 className="font-semibold mb-3">Multisig Configuration</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
            <div>
              <div className="label">Multisig Threshold</div>
              <div>{e8sToIcp(counts.config.multisigThresholdE8s)} ICP</div>
            </div>
            <div>
              <div className="label">Required Approvals</div>
              <div>{counts.config.requiredApprovals.toString()}</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({ icon, label, value }: { icon: ReactNode; label: string; value: string }) {
  return (
    <div className="card">
      <div className="flex items-center gap-2 text-delta-500 dark:text-delta-300 text-xs font-medium uppercase tracking-wide">
        {icon} {label}
      </div>
      <div className="mt-2 text-2xl font-bold">{value}</div>
    </div>
  );
}

function RateEditor({ rate, onChange }: { rate: number; onChange: (v: number) => void }) {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(rate.toString());

  if (!editing) {
    return (
      <button className="underline decoration-dotted" onClick={() => setEditing(true)}>
        1 ICP = ${rate}
      </button>
    );
  }
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        const parsed = parseFloat(value);
        if (!isNaN(parsed) && parsed > 0) onChange(parsed);
        setEditing(false);
      }}
      className="flex items-center gap-1"
    >
      <input
        autoFocus
        className="w-14 rounded border border-delta-200 dark:border-delta-700 bg-transparent px-1"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onBlur={() => setEditing(false)}
      />
    </form>
  );
}
