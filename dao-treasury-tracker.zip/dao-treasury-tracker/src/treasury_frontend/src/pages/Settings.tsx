import { FormEvent, useEffect, useState } from "react";
import { useAuth } from "../auth/AuthContext";
import { RequireRole } from "../components/RequireRole";
import { icpToE8s, e8sToIcp } from "../lib/format";
import { TreasuryConfig } from "../declarations/treasury_backend";

export function Settings() {
  const { actor, isAuthenticated, refreshRole } = useAuth();
  const [initialized, setInitialized] = useState<boolean | null>(null);
  const [daoName, setDaoName] = useState("");
  const [config, setConfig] = useState<TreasuryConfig | null>(null);
  const [threshold, setThreshold] = useState("");
  const [required, setRequired] = useState("2");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  async function load() {
    if (!actor) return;
    const init = await actor.isInitialized();
    setInitialized(init);
    if (init) {
      const c = await actor.getConfig();
      setConfig(c);
      setThreshold(e8sToIcp(c.multisigThresholdE8s));
      setRequired(c.requiredApprovals.toString());
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [actor]);

  async function handleInit(e: FormEvent) {
    e.preventDefault();
    if (!actor) return;
    setBusy(true);
    try {
      const result = await actor.init(daoName || "My DAO");
      if ("err" in result) setMessage(JSON.stringify(result.err));
      else {
        setMessage("Treasury initialized — you are the founding Admin.");
        await refreshRole();
        await load();
      }
    } finally {
      setBusy(false);
    }
  }

  async function handleUpdateConfig(e: FormEvent) {
    e.preventDefault();
    if (!actor || !config) return;
    setBusy(true);
    try {
      const result = await actor.updateConfig({
        ...config,
        multisigThresholdE8s: icpToE8s(threshold),
        requiredApprovals: BigInt(required),
      });
      if ("err" in result) setMessage(JSON.stringify(result.err));
      else {
        setMessage("Settings updated.");
        await load();
      }
    } finally {
      setBusy(false);
    }
  }

  if (!isAuthenticated) {
    return (
      <div className="space-y-4">
        <h1 className="text-xl sm:text-2xl font-bold">Settings</h1>
        <div className="card text-sm text-delta-500 dark:text-delta-300">Connect your wallet to continue.</div>
      </div>
    );
  }

  if (initialized === false) {
    return (
      <div className="space-y-4">
        <h1 className="text-xl sm:text-2xl font-bold">Initialize Treasury</h1>
        <form onSubmit={handleInit} className="card space-y-3 max-w-lg">
          <p className="text-sm text-delta-500 dark:text-delta-300">
            This treasury hasn't been set up yet. Initializing makes your connected principal the
            founding Admin.
          </p>
          <div>
            <label className="label" htmlFor="daoName">DAO Name</label>
            <input id="daoName" className="input" value={daoName} onChange={(e) => setDaoName(e.target.value)} placeholder="My DAO" />
          </div>
          <button className="btn-primary" disabled={busy}>{busy ? "Initializing..." : "Initialize"}</button>
          {message && <div className="text-sm text-emerald-600">{message}</div>}
        </form>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h1 className="text-xl sm:text-2xl font-bold">Settings</h1>
      <RequireRole allow={["Admin"]}>
        <form onSubmit={handleUpdateConfig} className="card space-y-4 max-w-lg">
          <h2 className="font-semibold">Multisig Configuration</h2>
          <div>
            <label className="label" htmlFor="threshold">Multisig Threshold (ICP)</label>
            <input id="threshold" className="input" value={threshold} onChange={(e) => setThreshold(e.target.value)} />
            <p className="text-xs text-delta-400 mt-1">Transfers at or above this amount require multiple approvals.</p>
          </div>
          <div>
            <label className="label" htmlFor="required">Required Approvals</label>
            <input id="required" type="number" min={1} className="input" value={required} onChange={(e) => setRequired(e.target.value)} />
          </div>
          <button className="btn-primary" disabled={busy}>{busy ? "Saving..." : "Save Settings"}</button>
          {message && <div className="text-sm text-emerald-600">{message}</div>}
        </form>
      </RequireRole>
    </div>
  );
}
