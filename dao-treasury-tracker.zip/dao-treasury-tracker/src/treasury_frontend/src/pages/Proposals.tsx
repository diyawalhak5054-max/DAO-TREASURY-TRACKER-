import { useEffect, useState } from "react";
import { useAuth, roleIs } from "../auth/AuthContext";
import { Proposal } from "../declarations/treasury_backend";
import { e8sToIcp, formatDate, shortPrincipal } from "../lib/format";
import { ProposalStatusBadge } from "../components/StatusBadge";
import { RequireRole } from "../components/RequireRole";
import { deltaConfirm, deltaToast } from "../lib/deltaBridge";

export function Proposals() {
  const { actor, role, principal } = useAuth();
  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [loading, setLoading] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);

  async function load() {
    if (!actor) return;
    setLoading(true);
    try {
      const result = await actor.getProposals();
      setProposals([...result].sort((a, b) => Number(b.createdAt - a.createdAt)));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [actor]);

  async function handleVote(id: bigint, approve: boolean) {
    if (!actor) return;
    const confirmed = await deltaConfirm(
      approve ? "Approve this proposal?" : "Reject this proposal?",
      "Confirm Vote"
    );
    if (!confirmed) return;
    setBusyId(id.toString() + approve);
    try {
      const result = approve ? await actor.approveProposal(id) : await actor.rejectProposal(id);
      if ("err" in result) alert(JSON.stringify(result.err));
      else deltaToast(result.ok);
      await load();
    } finally {
      setBusyId(null);
    }
  }

  const canVote = roleIs(role, "Admin") || roleIs(role, "Treasurer");

  return (
    <div className="space-y-4">
      <h1 className="text-xl sm:text-2xl font-bold">Multisig Proposals</h1>
      <RequireRole allow={["Admin", "Treasurer", "Member"]}>
        <div className="space-y-3">
          {loading && <div className="card text-center text-delta-400">Loading…</div>}
          {!loading && proposals.length === 0 && (
            <div className="card text-center text-delta-400">
              No proposals yet. Large transfers above the multisig threshold will appear here.
            </div>
          )}
          {proposals.map((p) => {
            const alreadyApproved = principal
              ? p.approvals.some((a) => a.toText() === principal.toText())
              : false;
            const isOpen = "Open" in p.status;
            return (
              <div key={p.id.toString()} className="card">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="font-semibold">Proposal #{p.id.toString()}</div>
                  <ProposalStatusBadge status={p.status} />
                </div>
                <p className="text-sm text-delta-500 dark:text-delta-300 mt-1">{p.description || "No description"}</p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-3 text-sm">
                  <div>
                    <div className="label">Amount</div>
                    {e8sToIcp(p.amountE8s)} ICP
                  </div>
                  <div>
                    <div className="label">To</div>
                    <span className="font-mono text-xs">{shortPrincipal(p.to, 8)}</span>
                  </div>
                  <div>
                    <div className="label">Approvals</div>
                    {p.approvals.length.toString()} / {p.requiredApprovals.toString()}
                  </div>
                  <div>
                    <div className="label">Created</div>
                    {formatDate(p.createdAt)}
                  </div>
                </div>

                {isOpen && canVote && (
                  <div className="mt-4 flex gap-2">
                    <button
                      className="btn-primary"
                      disabled={alreadyApproved || busyId === p.id.toString() + "true"}
                      onClick={() => handleVote(p.id, true)}
                    >
                      {alreadyApproved ? "Approved" : "Approve"}
                    </button>
                    <button
                      className="btn-secondary"
                      disabled={busyId === p.id.toString() + "false"}
                      onClick={() => handleVote(p.id, false)}
                    >
                      Reject
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </RequireRole>
    </div>
  );
}
