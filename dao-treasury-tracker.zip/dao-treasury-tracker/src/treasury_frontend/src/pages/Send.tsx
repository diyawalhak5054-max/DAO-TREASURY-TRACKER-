import { FormEvent, useState } from "react";
import { useAuth } from "../auth/AuthContext";
import { RequireRole } from "../components/RequireRole";
import { icpToE8s } from "../lib/format";
import { accountHexForPrincipal } from "../lib/actors";

export function Send() {
  return (
    <div className="space-y-4">
      <h1 className="text-xl sm:text-2xl font-bold">Send ICP</h1>
      <RequireRole allow={["Admin", "Treasurer"]}>
        <SendForm />
      </RequireRole>
    </div>
  );
}

function SendForm() {
  const { actor } = useAuth();
  const [destinationType, setDestinationType] = useState<"principal" | "account">("principal");
  const [destination, setDestination] = useState("");
  const [amount, setAmount] = useState("");
  const [memo, setMemo] = useState("0");
  const [description, setDescription] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<{ ok?: string; err?: string } | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!actor) return;
    setSubmitting(true);
    setResult(null);
    try {
      const amountE8s = icpToE8s(amount);
      const accountHex =
        destinationType === "principal" ? accountHexForPrincipal(destination.trim()) : destination.trim();
      const response = await actor.sendICP(accountHex, amountE8s, BigInt(memo || "0"), description);
      if ("ok" in response) {
        setResult({ ok: response.ok });
        setDestination("");
        setAmount("");
        setDescription("");
      } else {
        setResult({ err: JSON.stringify(response.err) });
      }
    } catch (err) {
      setResult({ err: err instanceof Error ? err.message : "Something went wrong" });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="card space-y-4 max-w-lg">
      <div>
        <div className="label">Destination Type</div>
        <div className="flex gap-2">
          {(["principal", "account"] as const).map((t) => (
            <button
              type="button"
              key={t}
              onClick={() => setDestinationType(t)}
              className={`flex-1 rounded-xl px-3 py-2 text-sm font-medium border ${
                destinationType === t
                  ? "bg-delta-800 text-white border-delta-800"
                  : "border-delta-200 dark:border-delta-700"
              }`}
            >
              {t === "principal" ? "Principal ID" : "Account ID (hex)"}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="label" htmlFor="destination">
          {destinationType === "principal" ? "Recipient Principal" : "Recipient Account (hex)"}
        </label>
        <input
          id="destination"
          className="input font-mono"
          value={destination}
          onChange={(e) => setDestination(e.target.value)}
          placeholder={destinationType === "principal" ? "aaaaa-aa..." : "64-character hex"}
          required
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="label" htmlFor="amount">Amount (ICP)</label>
          <input
            id="amount"
            className="input"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="0.00"
            required
          />
        </div>
        <div>
          <label className="label" htmlFor="memo">Memo (optional)</label>
          <input id="memo" className="input" value={memo} onChange={(e) => setMemo(e.target.value)} />
        </div>
      </div>

      <div>
        <label className="label" htmlFor="description">Description</label>
        <input
          id="description"
          className="input"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="e.g. Contributor payout for July"
        />
      </div>

      <p className="text-xs text-delta-400">
        Amounts at or above the configured multisig threshold will create a proposal requiring
        additional approvals instead of transferring immediately.
      </p>

      <button className="btn-primary w-full" disabled={submitting}>
        {submitting ? "Submitting..." : "Send"}
      </button>

      {result?.ok && <div className="text-sm text-emerald-600">{result.ok}</div>}
      {result?.err && <div className="text-sm text-rose-600">{result.err}</div>}
    </form>
  );
}
