import { FormEvent, useState } from "react";
import { QrCode } from "lucide-react";
import { useAuth } from "../auth/AuthContext";
import { RequireRole } from "../components/RequireRole";
import { icpToE8s } from "../lib/format";
import { accountHexForPrincipal, treasuryAccountHex } from "../lib/actors";
import { isDeltaApp, deltaConfirm, deltaToast, deltaScanQR, deltaShowQRCode, deltaWalletPayment } from "../lib/deltaBridge";

export function Send() {
  return (
    <div className="space-y-4">
      <h1 className="text-xl sm:text-2xl font-bold">Send ICP</h1>
      <RequireRole allow={["Admin", "Treasurer"]}>
        <SendForm />
      </RequireRole>
      <DepositCard />
    </div>
  );
}

function SendForm() {
  const { actor } = useAuth();
  const [destinationType, setDestinationType] = useState<"principal" | "account">("principal");
  const [destination, setDestination] = useState("");
  const [amount, setAmount] = useState("");
  const [memo, setMemo] = useState("0");
  const [description, setDescription] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<{ ok?: string; err?: string } | null>(null);

  async function handleScan() {
    const scanned = await deltaScanQR();
    if (scanned) setDestination(scanned);
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!actor) return;

    const confirmed = await deltaConfirm(
      `Send ${amount || "0"} ICP to ${destination.slice(0, 12)}...?`,
      "Authorize Transfer"
    );
    if (!confirmed) return;

    setSubmitting(true);
    setResult(null);
    try {
      const amountE8s = icpToE8s(amount);
      const accountHex =
        destinationType === "principal" ? accountHexForPrincipal(destination.trim()) : destination.trim();
      const response = await actor.sendICP(accountHex, amountE8s, BigInt(memo || "0"), description);
      if ("ok" in response) {
        setResult({ ok: response.ok });
        deltaToast(response.ok);
        setDestination("");
        setAmount("");
        setDescription("");
      } else {
        setResult({ err: JSON.stringify(response.err) });
      }
    } catch (err) {
      setResult({ err: err instanceof Error ? err.message : "Something went wrong" });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="card space-y-4 max-w-lg">
      <div>
        <div className="label">Destination Type</div>
        <div className="flex gap-2">
          {(["principal", "account"] as const).map((t) => (
            <button
              type="button"
              key={t}
              onClick={() => setDestinationType(t)}
              className={`flex-1 rounded-xl px-3 py-2 text-sm font-medium border ${
                destinationType === t
                  ? "bg-delta-800 text-white border-delta-800"
                  : "border-delta-200 dark:border-delta-700"
              }`}
            >
              {t === "principal" ? "Principal ID" : "Account ID (hex)"}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="label" htmlFor="destination">
          {destinationType === "principal" ? "Recipient Principal" : "Recipient Account (hex)"}
        </label>
        <div className="flex gap-2">
          <input
            id="destination"
            className="input font-mono"
            value={destination}
            onChange={(e) => setDestination(e.target.value)}
            placeholder={destinationType === "principal" ? "aaaaa-aa..." : "64-character hex"}
            required
          />
          {isDeltaApp() && (
            <button type="button" className="btn-secondary !px-3" onClick={handleScan} title="Scan QR code">
              <QrCode size={16} />
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="label" htmlFor="amount">Amount (ICP)</label>
          <input
            id="amount"
            className="input"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="0.00"
            required
          />
        </div>
        <div>
          <label className="label" htmlFor="memo">Memo (optional)</label>
          <input id="memo" className="input" value={memo} onChange={(e) => setMemo(e.target.value)} />
        </div>
      </div>

      <div>
        <label className="label" htmlFor="description">Description</label>
        <input
          id="description"
          className="input"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="e.g. Contributor payout for July"
        />
      </div>

      <p className="text-xs text-delta-400">
        Amounts at or above the configured multisig threshold will create a proposal requiring
        additional approvals instead of transferring immediately.
      </p>

      <button className="btn-primary w-full" disabled={submitting}>
        {submitting ? "Submitting..." : "Send"}
      </button>

      {result?.ok && <div className="text-sm text-emerald-600">{result.ok}</div>}
      {result?.err && <div className="text-sm text-rose-600">{result.err}</div>}
    </form>
  );
}

/**
 * Deposit to the treasury directly from the member's personal Delta Wallet
 * balance, using Delta's native `walletPayment` bridge. This does NOT go
 * through Internet Identity or our canister's ACL — Delta signs and moves
 * the funds itself — so it's available to any member running inside the
 * Delta app, independent of the Send form above. If the member is also
 * connected via Internet Identity, the deposit is additionally logged to
 * the on-chain transaction history via recordDeposit.
 */
function DepositCard() {
  const { actor } = useAuth();
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  if (!isDeltaApp()) return null;

  async function handleDeposit(e: FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setMessage(null);
    try {
      const parsed = parseFloat(amount);
      if (isNaN(parsed) || parsed <= 0) throw new Error("Enter a valid amount");

      const confirmed = await deltaConfirm(`Deposit ${amount} ICP to the treasury?`, "Confirm Deposit");
      if (!confirmed) {
        setSubmitting(false);
        return;
      }

      const paymentResult = await deltaWalletPayment("ICP", treasuryAccountHex(), parsed, note || "Treasury deposit");
      if (!paymentResult || !paymentResult.success) {
        throw new Error(paymentResult?.error ?? "Delta Wallet payment failed or was cancelled");
      }

      // Best-effort: log it on-chain if this member also has a canister session.
      if (actor) {
        try {
          await actor.recordDeposit(icpToE8s(amount), 0n, note);
        } catch (logErr) {
          console.warn("Deposit succeeded but could not be logged on-chain (connect Internet Identity to log deposits):", logErr);
        }
      }

      deltaToast("Deposit sent!");
      setMessage("Deposit sent via Delta Wallet.");
      setAmount("");
      setNote("");
    } catch (err) {
      setMessage(err instanceof Error ? err.message : "Deposit failed");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleDeposit} className="card space-y-3 max-w-lg">
      <h2 className="font-semibold">Deposit via Delta Wallet</h2>
      <p className="text-xs text-delta-400">
        Send ICP from your personal Delta Wallet balance straight into the treasury. Works for
        any member — no Admin/Treasurer role or Internet Identity login required.
      </p>
      <div className="flex items-center gap-2">
        <button
          type="button"
          className="btn-secondary !px-3 shrink-0"
          onClick={() => deltaShowQRCode(treasuryAccountHex(), "dots")}
          title="Show treasury deposit address as a QR code"
        >
          <QrCode size={16} />
        </button>
        <input
          className="input"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="Amount (ICP)"
          required
        />
      </div>
      <input className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Note (optional)" />
      <button className="btn-primary w-full" disabled={submitting}>
        {submitting ? "Sending..." : "Deposit"}
      </button>
      {message && <div className="text-sm text-delta-600 dark:text-delta-300">{message}</div>}
    </form>
  );
}
