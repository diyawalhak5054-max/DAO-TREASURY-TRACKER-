import { useEffect, useRef, useState } from "react";
import { Download, Upload } from "lucide-react";
import { useAuth } from "../auth/AuthContext";
import { Transaction } from "../declarations/treasury_backend";
import { e8sToIcp, formatDate, shortPrincipal } from "../lib/format";
import { downloadCsv, parseCsvFile } from "../lib/csv";
import { TxStatusBadge } from "../components/StatusBadge";
import { RequireRole } from "../components/RequireRole";

export function Transactions() {
  const { actor } = useAuth();
  const [txs, setTxs] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(false);
  const [importing, setImporting] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  async function load() {
    if (!actor) return;
    setLoading(true);
    try {
      const result = await actor.getTransactions();
      setTxs([...result].sort((a, b) => Number(b.date - a.date)));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [actor]);

  async function handleExport() {
    if (!actor) return;
    const csv = await actor.exportTransactionsCSV();
    downloadCsv(`treasury-transactions-${Date.now()}.csv`, csv);
  }

  async function handleImportFile(file: File) {
    if (!actor) return;
    setImporting(true);
    try {
      const rows = await parseCsvFile(file);
      for (const row of rows) {
        if (!row.to || !row.amountE8s) continue;
        await actor.importTransactionRecord(
          BigInt(row.date ? Date.parse(row.date) * 1_000_000 : Date.now() * 1_000_000),
          row.from ?? "imported",
          row.to,
          BigInt(row.amountE8s),
          BigInt(row.memo ?? "0"),
          row.blockHeight ? [BigInt(row.blockHeight)] : []
        );
      }
      await load();
    } catch (err) {
      alert(err instanceof Error ? err.message : "Import failed");
    } finally {
      setImporting(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="text-xl sm:text-2xl font-bold">Transaction History</h1>
        <div className="flex gap-2">
          <button className="btn-secondary" onClick={handleExport}>
            <Download size={16} className="mr-2" /> Export CSV
          </button>
          <RequireRole allow={["Admin"]}>
            <>
              <input
                ref={fileRef}
                type="file"
                accept=".csv"
                className="hidden"
                onChange={(e) => e.target.files?.[0] && handleImportFile(e.target.files[0])}
              />
              <button className="btn-secondary" onClick={() => fileRef.current?.click()} disabled={importing}>
                <Upload size={16} className="mr-2" /> {importing ? "Importing..." : "Import CSV"}
              </button>
            </>
          </RequireRole>
        </div>
      </div>

      <div className="card overflow-x-auto p-0">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs uppercase tracking-wide text-delta-500 dark:text-delta-300 border-b border-delta-100 dark:border-delta-800">
              <th className="px-4 py-3">Date</th>
              <th className="px-4 py-3">To</th>
              <th className="px-4 py-3">Amount</th>
              <th className="px-4 py-3">Memo</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Block</th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr><td colSpan={6} className="px-4 py-6 text-center text-delta-400">Loading…</td></tr>
            )}
            {!loading && txs.length === 0 && (
              <tr><td colSpan={6} className="px-4 py-6 text-center text-delta-400">No transactions yet.</td></tr>
            )}
            {txs.map((tx) => (
              <tr key={tx.id.toString()} className="border-b border-delta-50 dark:border-delta-800/60">
                <td className="px-4 py-3 whitespace-nowrap">{formatDate(tx.date)}</td>
                <td className="px-4 py-3 font-mono text-xs">{shortPrincipal(tx.to, 8)}</td>
                <td className="px-4 py-3 whitespace-nowrap">{e8sToIcp(tx.amountE8s)} ICP</td>
                <td className="px-4 py-3">{tx.memo.toString()}</td>
                <td className="px-4 py-3"><TxStatusBadge status={tx.status} /></td>
                <td className="px-4 py-3">{tx.blockHeight.length ? tx.blockHeight[0].toString() : "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
