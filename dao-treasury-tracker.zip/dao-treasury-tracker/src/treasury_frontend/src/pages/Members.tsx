import { FormEvent, useEffect, useState } from "react";
import { Principal } from "@dfinity/principal";
import { useAuth } from "../auth/AuthContext";
import { Member, Role } from "../declarations/treasury_backend";
import { RoleBadge } from "../components/RoleBadge";
import { RequireRole } from "../components/RequireRole";
import { shortPrincipal } from "../lib/format";

function roleFromString(s: string): Role {
  if (s === "Admin") return { Admin: null };
  if (s === "Treasurer") return { Treasurer: null };
  return { Member: null };
}

export function Members() {
  const { actor, principal } = useAuth();
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(false);

  async function load() {
    if (!actor) return;
    setLoading(true);
    try {
      setMembers(await actor.getMembers());
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [actor]);

  return (
    <div className="space-y-4">
      <h1 className="text-xl sm:text-2xl font-bold">Members</h1>

      <RequireRole allow={["Admin", "Treasurer", "Member"]}>
        <div className="card p-0 overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs uppercase tracking-wide text-delta-500 dark:text-delta-300 border-b border-delta-100 dark:border-delta-800">
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">Principal</th>
                <th className="px-4 py-3">Role</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {loading && <tr><td colSpan={4} className="px-4 py-6 text-center text-delta-400">Loading…</td></tr>}
              {members.map((m) => (
                <tr key={m.principal.toText()} className="border-b border-delta-50 dark:border-delta-800/60">
                  <td className="px-4 py-3">{m.name}</td>
                  <td className="px-4 py-3 font-mono text-xs">{shortPrincipal(m.principal.toText(), 8)}</td>
                  <td className="px-4 py-3"><RoleBadge role={m.role} /></td>
                  <td className="px-4 py-3 text-right">
                    <RequireRole allow={["Admin"]}>
                      <MemberActions member={m} isSelf={m.principal.toText() === principal?.toText()} onChange={load} />
                    </RequireRole>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </RequireRole>

      <RequireRole allow={["Admin"]}>
        <AddMemberForm onAdded={load} />
      </RequireRole>
    </div>
  );
}

function MemberActions({ member, isSelf, onChange }: { member: Member; isSelf: boolean; onChange: () => void }) {
  const { actor } = useAuth();
  const [busy, setBusy] = useState(false);

  async function updateRole(role: Role) {
    if (!actor) return;
    setBusy(true);
    try {
      await actor.updateMemberRole(member.principal, role);
      onChange();
    } finally {
      setBusy(false);
    }
  }

  async function remove() {
    if (!actor || isSelf) return;
    if (!confirm(`Remove ${member.name}?`)) return;
    setBusy(true);
    try {
      await actor.removeMember(member.principal);
      onChange();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex items-center justify-end gap-2">
      <select
        className="input !w-auto !py-1.5 text-xs"
        disabled={busy}
        value={Object.keys(member.role)[0]}
        onChange={(e) => updateRole(roleFromString(e.target.value))}
      >
        <option value="Admin">Admin</option>
        <option value="Treasurer">Treasurer</option>
        <option value="Member">Member</option>
      </select>
      <button className="text-xs text-rose-600 disabled:opacity-40" disabled={isSelf || busy} onClick={remove}>
        Remove
      </button>
    </div>
  );
}

function AddMemberForm({ onAdded }: { onAdded: () => void }) {
  const { actor } = useAuth();
  const [principalText, setPrincipalText] = useState("");
  const [name, setName] = useState("");
  const [role, setRole] = useState("Member");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!actor) return;
    setSubmitting(true);
    setError(null);
    try {
      const p = Principal.fromText(principalText.trim());
      const result = await actor.addMember(p, name.trim() || "Unnamed", roleFromString(role));
      if ("err" in result) {
        setError(JSON.stringify(result.err));
      } else {
        setPrincipalText("");
        setName("");
        onAdded();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Invalid principal");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="card space-y-3 max-w-lg">
      <h2 className="font-semibold">Add Member</h2>
      <div>
        <label className="label" htmlFor="principal">Principal ID</label>
        <input id="principal" className="input font-mono" value={principalText} onChange={(e) => setPrincipalText(e.target.value)} required />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="label" htmlFor="name">Name</label>
          <input id="name" className="input" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div>
          <label className="label" htmlFor="role">Role</label>
          <select id="role" className="input" value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="Admin">Admin</option>
            <option value="Treasurer">Treasurer</option>
            <option value="Member">Member</option>
          </select>
        </div>
      </div>
      <button className="btn-primary" disabled={submitting}>{submitting ? "Adding..." : "Add Member"}</button>
      {error && <div className="text-sm text-rose-600">{error}</div>}
    </form>
  );
}
