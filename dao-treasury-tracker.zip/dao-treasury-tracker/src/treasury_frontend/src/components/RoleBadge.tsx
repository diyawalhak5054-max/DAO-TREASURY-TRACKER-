import { Role } from "../declarations/treasury_backend";

function roleLabel(role: Role | null): string {
  if (!role) return "Guest";
  if ("Admin" in role) return "Admin";
  if ("Treasurer" in role) return "Treasurer";
  return "Member";
}

const colors: Record<string, string> = {
  Admin: "bg-delta-800 text-white",
  Treasurer: "bg-delta-200 text-delta-900",
  Member: "bg-delta-50 text-delta-700",
  Guest: "bg-gray-100 text-gray-600",
};

export function RoleBadge({ role }: { role: Role | null }) {
  const label = roleLabel(role);
  return <span className={`badge ${colors[label]}`}>{label}</span>;
}
