import { ReactNode } from "react";
import { useAuth, roleIs } from "../auth/AuthContext";

/**
 * Renders children only if the connected member has one of the allowed
 * roles. Otherwise shows a short explanatory message. Used to gate
 * Send / Members / Settings actions per the Admin/Treasurer requirement.
 */
export function RequireRole({
  allow,
  children,
}: {
  allow: Array<"Admin" | "Treasurer" | "Member">;
  children: ReactNode;
}) {
  const { role, isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return (
      <div className="card text-center text-sm text-delta-500 dark:text-delta-300">
        Connect your wallet to continue.
      </div>
    );
  }

  const allowed = allow.some((r) => roleIs(role, r));
  if (!allowed) {
    return (
      <div className="card text-center text-sm text-delta-500 dark:text-delta-300">
        Your role doesn't have access to this action. Required: {allow.join(" or ")}.
      </div>
    );
  }

  return <>{children}</>;
}
