import { useEffect, useState } from "react";
import { Moon, Sun, Wallet, LogOut, Menu, Link2 } from "lucide-react";
import { useAuth } from "../auth/AuthContext";
import { useTheme } from "../auth/ThemeContext";
import { shortPrincipal } from "../lib/format";
import { isDeltaApp, deltaAuthByIdentToken, getStoredDeltaToken, deltaToast } from "../lib/deltaBridge";

export function Navbar({ onMenuClick }: { onMenuClick: () => void }) {
  const { isAuthenticated, principal, connect, disconnect, availableWallets } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [pickerOpen, setPickerOpen] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [deltaLinked, setDeltaLinked] = useState(() => !!getStoredDeltaToken());

  useEffect(() => {
    setDeltaLinked(!!getStoredDeltaToken());
  }, []);

  async function handleConnect(walletId: "internet-identity") {
    setConnecting(true);
    setPickerOpen(false);
    try {
      await connect(walletId);
    } catch (err) {
      alert(err instanceof Error ? err.message : "Failed to connect");
    } finally {
      setConnecting(false);
    }
  }

  async function handleLinkDelta() {
    const token = await deltaAuthByIdentToken();
    if (token) {
      setDeltaLinked(true);
      deltaToast("Delta Wallet linked");
    }
  }

  return (
    <header className="sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-delta-100 dark:border-delta-800 bg-white/90 dark:bg-delta-900/90 backdrop-blur px-4 py-3 sm:px-6">
      <div className="flex items-center gap-3">
        <button
          className="lg:hidden rounded-lg p-2 hover:bg-delta-50 dark:hover:bg-delta-800"
          onClick={onMenuClick}
          aria-label="Open menu"
        >
          <Menu size={20} />
        </button>
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-lg bg-delta-800 flex items-center justify-center text-white font-bold text-sm">
            DT
          </div>
          <span className="font-semibold text-delta-900 dark:text-white hidden sm:inline">
            DAO Treasury Tracker
          </span>
        </div>
      </div>

      <div className="flex items-center gap-2">
        {isDeltaApp() && (
          <button
            onClick={handleLinkDelta}
            className={`hidden sm:flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium ${
              deltaLinked
                ? "text-emerald-700 bg-emerald-50 dark:bg-emerald-900/30"
                : "text-delta-600 hover:bg-delta-50 dark:hover:bg-delta-800"
            }`}
            title="Delta Wallet's native features (payments, QR, dialogs) — separate from canister login below"
          >
            <Link2 size={14} /> {deltaLinked ? "Delta Linked" : "Link Delta Wallet"}
          </button>
        )}

        <button
          onClick={toggleTheme}
          className="rounded-lg p-2 hover:bg-delta-50 dark:hover:bg-delta-800"
          aria-label="Toggle theme"
        >
          {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
        </button>

        {isAuthenticated ? (
          <div className="flex items-center gap-2">
            <span className="hidden sm:inline text-xs rounded-full bg-delta-50 dark:bg-delta-800 px-3 py-1.5 font-mono">
              {shortPrincipal(principal?.toText() ?? "")}
            </span>
            <button onClick={() => disconnect()} className="btn-secondary !px-3" title="Disconnect">
              <LogOut size={16} />
            </button>
          </div>
        ) : (
          <div className="relative">
            <button
              className="btn-primary"
              disabled={connecting}
              onClick={() => setPickerOpen((v) => !v)}
            >
              <Wallet size={16} className="mr-2" />
              {connecting ? "Connecting..." : "Connect"}
            </button>
            {pickerOpen && (
              <div className="absolute right-0 mt-2 w-56 rounded-xl border border-delta-100 dark:border-delta-800 bg-white dark:bg-delta-900 shadow-lg overflow-hidden">
                {availableWallets.map((w) => (
                  <button
                    key={w.id}
                    onClick={() => handleConnect(w.id)}
                    className="w-full text-left px-4 py-3 text-sm hover:bg-delta-50 dark:hover:bg-delta-800"
                  >
                    {w.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </header>
  );
}
