import { TransactionStatus, ProposalStatus } from "../declarations/treasury_backend";

const txColors: Record<string, string> = {
  Pending: "bg-amber-100 text-amber-800",
  Completed: "bg-emerald-100 text-emerald-800",
  Rejected: "bg-rose-100 text-rose-800",
  Failed: "bg-rose-100 text-rose-800",
};

const proposalColors: Record<string, string> = {
  Open: "bg-amber-100 text-amber-800",
  Approved: "bg-emerald-100 text-emerald-800",
  Executed: "bg-delta-100 text-delta-800",
  Rejected: "bg-rose-100 text-rose-800",
};

export function TxStatusBadge({ status }: { status: TransactionStatus }) {
  const key = Object.keys(status)[0];
  return <span className={`badge ${txColors[key]}`}>{key}</span>;
}

export function ProposalStatusBadge({ status }: { status: ProposalStatus }) {
  const key = Object.keys(status)[0];
  return <span className={`badge ${proposalColors[key]}`}>{key}</span>;
}
